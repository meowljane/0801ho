let key = App.loadSpritesheet("key.png");
let testObject = App.loadSpritesheet("keymin.png");
let testObjecttwo = App.loadSpritesheet("door.png");
// 플레이어가 입장할 때 동작하는 함수
App.onJoinPlayer.Add(function (player) {
	Map.putTileEffect(9, 12, TileEffectType.IMPASSABLE);
	Map.putTileEffect(15, 11, TileEffectType.IMPASSABLE);
	Map.putObject(15, 11, testObject, { overlap: true });
	Map.putObject(9, 12, testObjecttwo, { overlap: true });
	player.tag = {
		widget: null,
	};

	player.tag.widget = player.showWidget("sample.html", "sidebar", 300, 300);
	player.tag.widget.onMessage.Add(function (player, data) {
		if (data.type == "open") {
			player.showCenterLabel("문이 열렸습니다.");
			Map.putObject(9, 12, null, { overlap: true });
			Map.putTileEffect(9, 12, TileEffectType.NONE);
		}
	});
	player.sendUpdated();
});

App.onObjectAttacked.Add(function(player, x, y){
    if (x ==15 && y ==11) {
		player.tag.widget.sendMessage({
			image: key.body,
			text: "문을 열 수 있는 열쇠",
		});
		Map.putObject(15, 11, null, { overlap: true });
		Map.putTileEffect(15, 11, TileEffectType.NONE);
    }
});
