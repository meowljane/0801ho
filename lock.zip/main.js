
	let testObjecttwo = App.loadSpritesheet("talk2.png");
	let testObject = App.loadSpritesheet("talk.png");	
		
		App.onJoinPlayer.Add(function (player) {
			Map.putObject(19, 14, testObject, { overlap: true });
		player.tag = {
			widget: null,
		};

		App.onObjectAttacked.Add(function(sender, x, y){
		player.tag.widget = player.showWidget("sample.html", "top", 600, 500);
		var talk = 1;	
	
	

		player.tag.widget.onMessage.Add(function (player, msg) {
			if (msg.type == "close") {
				player.showCenterLabel("새로운 카톡이 도착했습니다.");
				player.tag.widget.destroy();
				player.tag.widget = null;
				Map.putObject(19, 14, testObjecttwo, { overlap: false });
			}
		});

	})


	});
	



	